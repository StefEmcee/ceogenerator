**We have a new help channel system!**

Please see <#704250143020417084> for further information.

A more detailed guide can be found on [our website](https://pythondiscord.com/pages/resources/guides/help-channels/).
